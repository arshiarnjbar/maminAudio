export const heroDefaultCss = {
    minHeight: "724px",
    height: "100%",
}